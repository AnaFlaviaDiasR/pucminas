/**
 * Ponteiro
 * @author Max do Val Machado
 * @version 2 01/2015
 */
class Ponteiro01Array {
   public static void main (String[] args) {
      int[] vet = new int [10];
      System.out.println(vet);

      vet = new int [10];
      System.out.println(vet);
   }
}
