#include <stdio.h> 

int main(int argc, char *argv[]) { 
   printf ("Ola pessoal!!!\n\n"); 
   return 0; 
}
