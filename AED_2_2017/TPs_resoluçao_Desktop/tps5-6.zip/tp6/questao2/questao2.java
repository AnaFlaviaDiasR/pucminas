/**
*Programa para ler HTML e procurar informaçoes dentro do arquivo
*@author Bruno Rodrigues Paschoalino
*@version questao1.java 1.0 - 08/09/2017
*/

import java.io.*;

public class questao2
{
    public static void main(String[] args) throws Exception
    {
        String entrada [] = new String [1000];

        boolean teste = false;

        int numEntrada = 0;

        MyIO.setCharset("UTF-8");

        Pilha resp = new Pilha();

        do
        {
        
            entrada[numEntrada] = MyIO.readLine();

            teste = IfFlag(entrada[numEntrada]);

            numEntrada++;

        } while (teste == false);

        numEntrada--;

        for ( int i = 0; i < numEntrada; i++ )
        {
            Series aux = new Series();

            aux.ler(entrada[i]);

            resp.insert(aux);
        }

        doPilha(resp);
    }

    public static void doPilha ( Pilha resp ) throws Exception
    {
        int operacoes = MyIO.readInt();

        String array [] = new String [0];

        String aux = "";

        for ( int i = 0; i < operacoes; i++)
        {
            Series auxiliar = new Series();

            aux = MyIO.readLine();

            array = aux.split(" ");

            if ( array[0].equals("I") )
            {
                try
                {
                    auxiliar.ler( array[1] );
                }
                catch( Exception e )
                {
                }

                resp.insert( auxiliar );
            }
            else if ( array[0].equals( "R" ) )
            {
                MyIO.println("(R) " + resp.remove().getNome() );
            }
        }
        resp.print();
    }

    /**
    *Metodo de verificaçao de flag das entradas
    *@param palavra String
    *@return teste boolean
    */
    public static boolean IfFlag ( String palavra )
    {
        String flag = "FIM";

        boolean teste = false;

        if ( palavra.length() == flag.length() )
        {
            for ( int i = 0; i < palavra.length(); i++)
            {
                if ( palavra.charAt(i) != flag.charAt(i) )
                {
                    return false;
                }
                else teste = true;
            }
        }
        return teste;
    }
}

class Series
{
    private String nome;
    private String formato;
    private String duracao;
    private String pais;
    private String idioma;
    private String emissora;
    private String transmissao;
    private int temporadas;
    private int episodios;

    /**
    *Metodo para remover tags do HTML
    *@param linha String
    *@return linha String
    */
    String removeTag( String linha )
    {
        for ( int i = linha.indexOf("<"); linha.contains("<") && linha.contains(">"); i = linha.indexOf("<") )
        {
            int j = linha.indexOf(">");

            linha = linha.replace(linha.substring(i, (j+1)), "" );
        }
        
        return linha;
    }

    /**
    *Metodo para ler o html e procurar as informaçoes
    *@param entrada String
    */
    void ler( String entrada ) throws Exception
    {
        Arq.openRead("/tmp/" + entrada, "UTF-8");

        String linha = Arq.readLine();

        String aux = entrada.replace( '_' , ' ' );

        this.setNome(aux.replace( ".html", "") );

        while(linha.contains("</html>") == false )
        {
            linha = Arq.readLine();

            if(linha.contains(">Formato</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                this.setFormato(linha);

                linha = Arq.readLine();
            }

            if( linha.contains(">Duração</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                this.setDuracao(linha);

                linha = Arq.readLine();
            }

            if ( linha.contains(">País de origem</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                linha = linha.replace("&#160;", "");

                linha = linha.replace("&nbsp;", "");

                this.setPais(linha);

                linha = Arq.readLine();
            }

            if( linha.contains(">Idioma original</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                this.setIdioma(linha);

                linha = Arq.readLine();
            }

            if( linha.contains(">Emissora de televisão original</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                this.setEmissora(linha);

                linha = Arq.readLine();
            }

            if( linha.contains(">Transmissão original</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                linha = linha.replace("&#160;", "");

                linha = linha.replace("&nbsp;", "");

                this.setTransmissao(linha);

                linha = Arq.readLine();
            }

            if( linha.contains(">N.º de temporadas</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                String aux1 [] = new String [50];

                aux1 = linha.split(" ");

                try
                {
                    this.setTemporadas(Integer.parseInt(aux1[0]) );
                }
                catch(Exception e)
                {
                    throw new Exception("erro" + e);
                }
            }

            if( linha.contains(">N.º de episódios</td>") )
            {
                linha = Arq.readLine();

                linha = removeTag(linha);

                String aux2 [] = new String [50];

                aux2 = linha.split(" ");

                try
                {
                    this.setEpisodios(Integer.parseInt(aux2[0]) );
                }
                catch(Exception e)
                {
                    throw new Exception("erro" + e);
                }
            }
        }
        Arq.close();
    }

    /**
    *Metodo clone
    *@return nome String
    *@return formato String
    *@return duracao String
    *@return pais String
    *@return idioma String
    *@return emissora String
    *@return transmissao String
    *@return temporadas int
    *@return episodios int
    */
    /*Series clone()
    {
        return new Series(this.getNome(), this.getFormato(), this.getDuracao(), this.getPais(), this.getIdioma(), this.getEmissora(), 
            this.getTransmissao(), this.getTemporadas(), this.getEpisodios() );
    }*/

    /**
    *Metodo para imprimir
    */
    void imprimir()
    {
        System.out.println(this.getNome() + " " + this.getFormato() + " " + this.getDuracao() + " " + 
            this.getPais() + " " + this.getIdioma() + " " + this.getEmissora() + " " + this.getTransmissao() + " " + this.getTemporadas()
             + " " + this.getEpisodios());
    }

    /**
    *Metodo construtor vazio
    *@param nome String
    *@param formato String
    *@param duracao String
    *@param pais String
    *@param idioma String
    *@param emissora String
    *@param transmissao String
    *@param temporadas int
    *@param episodios int
    */
    Series()
    {
        nome = formato = duracao = pais = idioma = emissora = transmissao = "";
        temporadas = episodios = 0;
    }

    /**
    *Metodo construtor
    *@param nome String
    *@param formato String
    *@param duracao String
    *@param pais String
    *@param idioma String
    *@param emissora String
    *@param transmissao String
    *@param temporadas int
    *@param episodios int
    */
    Series(String nome, String formato, String duracao, String pais, String idioma, String emissora,
     String transmissao, int temporadas, int episodios)
    {
        this.setNome(nome);
        this.setFormato(formato);
        this.setDuracao(duracao);
        this.setPais(pais);
        this.setIdioma(idioma);
        this.setEmissora(emissora);
        this.setTransmissao(transmissao);
        this.setTemporadas(temporadas);
        this.setEpisodios(episodios);
    }

    /**
    *Metodos get e set
    */

    String getNome() 
    {
        return this.nome;
    }

    void setNome( String nome )
    {
        this.nome = nome;
    }

    String getFormato()
    {
        return this.formato;
    }

    void setFormato( String formato )
    {
        this.formato = formato;
    }

    String getDuracao()
    {
        return this.duracao;
    }

    void setDuracao( String duracao )
    {
        this.duracao = duracao;
    }

    String getPais()
    {
        return this.pais;
    }

    void setPais( String pais )
    {
        this.pais = pais;
    }

    String getIdioma()
    {
        return this.idioma;
    }

    void setIdioma( String idioma )
    {
        this.idioma = idioma;
    }

    String getEmissora()
    {
        return this.emissora;
    }

    void setEmissora( String emissora )
    {
        this.emissora = emissora;
    }

    String getTransmissao()
    {
        return this.transmissao;
    }

    void setTransmissao( String transmissao )
    {
        this.transmissao = transmissao;
    }

    int getTemporadas()
    {
        return this.temporadas;
    }

    void setTemporadas( int temporadas )
    {
        this.temporadas = temporadas;
    }

    int getEpisodios()
    {
        return this.episodios;
    }

    void setEpisodios( int episodios )
    {
        this.episodios = episodios;
    }
}

class Celula {
    public Series elemento; // Elemento inserido na celula.
    public Celula prox; // Aponta a celula prox.
 
 
    /**
     * Construtor da classe.
     */
    public Celula() {
        this(null);
    }
 
    /**
     * Construtor da classe.
     * @param elemento int inserido na celula.
     */
    public Celula(Series elemento) {
      this.elemento = elemento;
      this.prox = null;
    }
}

class Pilha
{
    private Celula top;

    Pilha()
    {
        top = null;
    }

    void insert( Series serie )
    {
        Celula temp = new Celula(serie);

        temp.prox = top;

        top = temp;

        temp = null;
    }

    Series remove() throws Exception
    {
        if ( top == null )
        {
            throw new Exception("Erro a remover.");
        }

        Series resp = top.elemento;

        Celula temp = top;

        top = top.prox;

        temp = null;

        return resp;
    }

    void print()
    {
        for ( Celula i = top; i != null; i = i.prox )
        {
            i.elemento.imprimir();
        }
    }
}