class Celula 
{
    public int elemento; // Elemento inserido na celula.

    public Celula dir, esq, inf, sup;
 
    /**
     * Construtor da classe.
     */
    public Celula() {
        this(0, null,null,null, null);
    }
 
    /**
     * Construtor da classe.
     * @param elemento int inserido na celula.
     */
    public Celula( int elemento, Celula dir, Celula esq, Celula inf, Celula sup )
    {
    	this.elemento = elemento;

    	this.dir = null;

    	this.esq = null;

    	this.inf = null;

    	this.sup = null;
    }
}

class Matriz
{
	private Celula inicio;

	private int linha, coluna;

	Matriz( int linha, int coluna )
	{
		this.linha = linha;

		this.coluna = coluna;

		Celula temp = null;

		for ( int i = 1; i <= linha; i++ )
		{
			if ( inicio == null )
			{
				temp = new Celula();

				inicio = temp;
			}
			else
			{
				temp.inf = new Celula();

				temp.inf.sup = temp;

				temp = temp.inf;
			}

			for ( int j = 1; j < coluna; j++ )
			{
				if ( i == 1 )
				{
					temp.dir = new Celula();

					temp.dir.esq = temp;

					temp = temp.dir;
				}
				else
				{
					Celula up = temp.sup;

					temp.dir = new Celula();

					temp.dir.esq = temp;

					temp = temp.dir;

					up = up.dir;

					up.inf = temp;

					temp.sup = up;
				}
			}

			temp = inicio;

			while( temp.inf != null ) temp = temp.inf;
		}
	}

	void inserirMatriz( int elemento, int linha, int coluna )
	{
		Celula temp = this.inicio;

		int i = 1, j = 1;

		while ( i < linha )
		{
			temp = temp.dir;

			i++;
		}

		while ( j < coluna )
		{
			temp = temp.inf;

			j++;
		}

		temp.elemento = elemento;
	}

	void mostrarMatriz()
	{
		Celula temp = this.inicio;

		while ( temp != null )
		{
			for ( Celula i = temp; i != null; i = i.dir )
			{
				System.out.print( i.elemento + " " );
			}
		}
		System.out.println("");

		temp = temp.inf;
	}

	void procurarPrincipal()
	{
		for ( Celula i = inicio; i != null; i = i.dir.inf )
		{
			System.out.print(i.elemento + " ");
		}
		System.out.println("");
	}

	void procurarSecundaria()
	{
		Celula i = inicio;

		while ( i != null ) i = i.dir;

		for ( ; i != null; i = i.esq.inf )
		{
			System.out.print(i.elemento + " ");
		}

		System.out.println("");
	}
}

public class questao5
{
	public static void main(String[]args)
	{
		MyIO.setCharset("UTF-8");

		Matriz m1 = null;

		Matriz m2 = null;

		Matriz m3 = null;

		Matriz m4 = null;

		int instrucoes = MyIO.readInt();

		for ( int k = 0; k < instrucoes; k++ )
		{
			int linha = MyIO.readInt();

			int coluna = MyIO.readInt();

			m1 = new Matriz(linha, coluna);

			for ( int i = 1; i <= coluna; i++ )
			{
				for ( int j = 1; j <= linha; j++ )
				{
					int elemento = MyIO.readInt();

					m1.inserirMatriz(elemento, linha, coluna );
				}
			}

			int line = MyIO.readInt();

			int col = MyIO.readInt();

			m2 = new Matriz(line, col);

			for ( int i = 1; i <= col; i++ )
			{
				for ( int j = 1; j <= line; j++ )
				{
					int elemento = MyIO.readInt();

					m2.inserirMatriz(elemento, line, col);
				}
			}

			//metodo procurar diagonal principal m1
			//metodo procurar diagonal secundaria m1
			//metodo procurar diagonal principal m2
			//metodo procurar diagonal secundaria m2
			//m3 rebece soma de m1 e m2
			//mostra m3
			//m4 recebe multiplicacao de m1 e m2
			//mostra m4
		}

	}
}