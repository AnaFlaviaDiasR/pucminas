#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <time.h>


#define MAX 1000


struct Compare { 
  int val; 
  int index; 
};

/*
  Declara uma redução do OpenMP.
  Uma redução garante que a variável tem uma cópia em cada thread. Mas seus valores
  são reduzidos em uma variável global compartilhada.
  Esta redução garante que a variável usada como parâmetro, do tipo Compare,
  terá o maior valor ao final do processamento da thread.  
*/
#pragma omp declare reduction(maximum : struct Compare : omp_out = omp_in.val > omp_out.val ? omp_in : omp_out)

void selectionsort(int arr[], int size, int contador) {
    
 //  #pragma omp parallel 

     omp_set_num_threads(contador);	
     for (int i = size - 1; i > 0; --i) {
        struct Compare max;
        max.val = arr[i];
        max.index = i;

        #pragma omp parallel for //reduction(maximum:max)
        for (int j = i - 1; j >= 0; j--) {
            #pragma omp critical
	    {
	    if (arr[j] > max.val) {
                max.val = arr[j];
                max.index = j;
            }
	    }
	    int tn = omp_get_thread_num();
	    //printf("\nThread numero: %d ", tn);
        }

        int tmp = arr[i];
        arr[i] = max.val;
        arr[max.index] = tmp;
	
	
    }
}

int main()
{
	for(int w = 0;w<3;w++){
		printf("%d" , (MAX*1*(w+1)));
		int x[MAX*1*(w+1)];
	for(int j = 0;j<10;j++){
        
	for(int contador = 2; contador <=32; contador = contador * 2){
		for(int i=0;i<MAX*1*(w+1);i++){
		 x[i] = rand() % 10;
		}
		double tempoI = clock();

        selectionsort(x, MAX*1*(w+1), contador);
	
		double tempoF = clock();
        double procTime = ((double)tempoF - tempoI) / CLOCKS_PER_SEC;
        
        //printf("Tempo de processamento: %6.4f \n", procTime);

        printf("\t thread [%d]: %6.4f", contador, procTime);
	}
	printf("\n");
	}
}
        return 0;
	
}
